/*
	Programm:		        Messung, Berechnung und Anzeige des Temperaturwertes
  Beschreibung:       Alle Rechenoperationen mit Ganzzahlen (32Bit)
  
	Autor:              Rah
	Datum:			        21.09.2025
  letzte �nderung:  	
*/

#include "controller.h"

#define CS    _PORTB_,2
#define DOUT  _PORTB_,4
#define CLK   _PORTB_,5

uint16_t adc1268_in(void);
    
void setup (void)   // Initialisierungen
{
  bit_init(CS, OUT);
  bit_init(DOUT, IN);
  bit_init(CLK,OUT);
  
	adc_init();
  lcd_init();
  lcd_clear();
}

int main (void)
{
  uint32_t temp;
  int32_t  temperatur;
    
	setup();
	
	while(1)          // loop()
	{  
    temp = adc1268_in();
    temperatur = temp * 1000;               // max. 4095x1000 = 4095000
                                            // Ist n�tig, damit beim K�rzen
                                            // kein Genauigkeitsverlust auftritt.
                                            // Rechnung f�r eine Nachkommastelle
    temperatur = temperatur/3276 - 250;     // 3276 = Aufl�sung/Messbereich * 100
                                            // Offset: 25(�C) * 100 abziehen.
                                            // temperatur ist mit Faktor 10 f�r 
                                            // eine Nachkommastelle gespeichert.
    
    lcd_setcursor(1,4);
    
    if (temperatur<0) 
    { 
      temperatur = -temperatur;
      lcd_char('-');
    }
    else lcd_char(' ');
    
    lcd_int(temperatur/10);lcd_char(',');lcd_char(temperatur%10+0x30);    
    lcd_print(" �C");
    lcd_setcursor(2,12);
    lcd_int(temp);
    delay_ms(500);
	}
}

void setDCLK(uint8_t level)
{
    delay_100us(1);
    bit_write(CLK,level);
}

uint16_t adc1268_in(void)
{
  volatile uint16_t result;
  volatile uint8_t temp;
  
  bit_write(CS,0);
  
  for (uint8_t i = 0; i<3; i++)
  {
    setDCLK(0);
    setDCLK(1);
  }

  setDCLK(0);
  
  for (uint8_t bitcount=12; bitcount>0;bitcount--)
  {
    setDCLK(1);
    
    temp = bit_read(DOUT);
    result <<= 1;
    result |= temp;

    setDCLK(0);
  }
  bit_write(CS,1);
  delay_100us(2);   // Conversion time
  
  return result;
}
