/*-----------------------------------------------------------------------------+
	Programm:	Zeichensatz f�r gro�e Zahlen
	Autor:	Rahm
+------------------------------------------------------------------------------+
	Beschreibung:    Funktionen zur Ausgabe einer Zahl in gro�er Darstellung auf 
                   LC-Display. F�r die Darstellung einer Zahl werd 4 Display-
                   Zeichen verwendet.
+-----------------------------------------------------------------------------*/

#include "lcd.h"

const uint8_t Zeichen0[] = {		// Tabelle f�r selbstdefiniertes
				0b00001,	        // Zeichen 5 x 8 -Matrix
				0b00011,
				0b00000,
				0b00000,
				0b00000,
				0b00000,
				0b00000,
				0b00000,
				};
const uint8_t Zeichen1[] = {		// Tabelle f�r selbstdefiniertes
				0b00000,	        // Zeichen 5 x 8 -Matrix
				0b00000,
				0b00000,
				0b00000,
				0b00000,
				0b00000,
				0b00011,
				0b00001,
				};
const uint8_t Zeichen2[] = {		// Tabelle f�r selbstdefiniertes
				0b00001,	        // Zeichen 5 x 8 -Matrix
				0b00011,
				0b00011,
				0b00011,
				0b00011,
				0b00011,
				0b00011,
				0b00001
				};
const uint8_t Zeichen3[] = {		// Tabelle f�r selbstdefiniertes
				0b11110,	        // Zeichen 5 x 8 -Matrix
				0b11111,
				0b00011,
				0b00011,
				0b00011,
				0b00011,
				0b11111,
				0b11110
				};
const uint8_t Zeichen4[] = {		// Tabelle f�r selbstdefiniertes
				0b00011,	        // Zeichen 5 x 8 -Matrix
				0b00011,
				0b00011,
				0b00011,
				0b00011,
				0b00011,
				0b11111,
				0b11110
				};
const uint8_t Zeichen5[] = {		// Tabelle f�r selbstdefiniertes
				0b11110,	        // Zeichen 5 x 8 -Matrix
				0b11111,
				0b00000,
				0b00000,
				0b00000,
				0b00000,
				0b11110,
				0b11111
				};
const uint8_t Zeichen6[] = {		// Tabelle f�r selbstdefiniertes
				0b11110,	// Zeichen 5 x 8 -Matrix
				0b11111,
				0b00011,
				0b00011,
				0b00011,
				0b00011,
				0b00011,
				0b00001
				};
const uint8_t Zeichen7[] = {		// Tabelle f�r selbstdefiniertes
				0b00000,	// Zeichen 5 x 8 -Matrix
				0b00000,
				0b00000,
				0b00000,
				0b00000,
				0b00000,
				0b11111,
				0b11111
				};				
// Funktionsdeklaration
void lcd_bigchar(uint8_t Zeichen, uint8_t Zeile, uint8_t Spalte);

// Funktionsdefinition
void lcd_bigchar_init (void)
{
	lcd_defchar(Zeichen0,0);			// Zeichen definieren
	lcd_defchar(Zeichen1,1);
	lcd_defchar(Zeichen2,2);
	lcd_defchar(Zeichen3,3);
	lcd_defchar(Zeichen4,4);
	lcd_defchar(Zeichen5,5);			
	lcd_defchar(Zeichen6,6);	
	lcd_defchar(Zeichen7,7);
}

void lcd_bigchar(uint8_t Zeichen, uint8_t Zeile, uint8_t Spalte)
{	// StartAdresse ist immer Zeichenposition links unten
	unsigned char buf[4];	// Jedes Zeichen setzt sich aus
							// 4 5x8-Matrix-Zeichen zusammen
	switch (Zeichen)	// Zeichenanordnung:
	{	case '0':	buf[2]=0x02;	buf[3]=0x06;		//Display//
					    buf[0]=0x02;	buf[1]=0x04;		//////////////////////
					    break;	        							// buf[2] // buf[3] //
		case '1':	buf[2]=' ';		buf[3]=0x02;		//        //        //
					    buf[0]=' ';		buf[1]=0x02;		//        //        //
					    break;								        /////////////////////
		case '2':	buf[2]=0x00;	buf[3]=0x03;		// buf[0] // buf[1] //
		          buf[0]=0x02;	buf[1]=0x07;		//Start   //        //
		          break;   							        //Adresse //        //
		case '3':	buf[2]=0x00;	buf[3]=0x03;		//////////////////////
					    buf[0]=0x01;	buf[1]=0x04;
					    break;
		case '4':	buf[2]=0x02;	buf[3]=0x04;
					    buf[0]=' ';		buf[1]=0x02;
					    break;
		case '5':	buf[2]=0x02;	buf[3]=0x05;
					    buf[0]=0x01;	buf[1]=0x04;
					    break;
		case '6':	buf[2]=0x02;	buf[3]=0x05;
					    buf[0]=0x02;	buf[1]=0x04;
					    break;
		case '7':	buf[2]=0x00;	buf[3]=0x06;
					    buf[0]=' ';		buf[1]=0x02;
					    break;
		case '8':	buf[2]=0x02;	buf[3]=0x03;
					    buf[0]=0x02;	buf[1]=0x04;
					    break;
		case '9':	buf[2]=0x02;	buf[3]=0x03;
					    buf[0]=0x01;	buf[1]=0x04;
					    break;
    case '.':
		case ',':	buf[2]=' ';		buf[3]=' ';
					    buf[0]=0x2C;	buf[1]=' ';
					    break;
		case '-':	buf[2]=0x07;	buf[3]=' ';
					    buf[0]=' ';		buf[1]=' ';
					    break;
		case ' ':	buf[2]=' ';		buf[3]=' ';
					    buf[0]=' ';		buf[1]=' ';
					    break;
	}
	
	lcd_setcursor(Zeile,Spalte);
	lcd_char(buf[0]);
	lcd_char(buf[1]);
	lcd_setcursor(Zeile-1,Spalte);
	lcd_char(buf[2]);
	lcd_char(buf[3]);

}

