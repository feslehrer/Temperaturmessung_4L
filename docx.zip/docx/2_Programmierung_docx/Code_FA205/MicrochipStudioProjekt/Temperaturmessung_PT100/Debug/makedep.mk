################################################################################
# Automatically-generated file. Do not edit or delete the file
################################################################################

lib\communication.c

lib\delay.c

lib\interrupt.c

lib\in_out.c

lib\lcd.c

lib\spi.c

main.c

Zeichensatz_Gross.c

