/*
	Programm:		        SernsorRead-SPI
  Beschreibung:       Auslesen des Rohwertes vom ADS1286 mittels SPI-Befehlen

	Autor:              Rah
	Datum:			        18.09.2025
  letzte �nderung:  		
*/

#include "controller.h"
#include "spi.h"

uint16_t ADS1286_Read(void);
   
void setup (void)   // Initialisierungen
{  
	adc_init();
  lcd_init();
  lcd_clear();
  lcd_print(" Rohwert:");
  spi_init();
}

int main (void)
{
  uint16_t raw;
      
	setup();
	
	while(1)          // loop()
	{
  
    raw = ADS1286_Read();
		lcd_setcursor(2,6);
    
    lcd_int(raw);
    delay_ms(100);
	}
}

uint16_t ADS1286_Read(void)
{
  uint16_t result = 0;

  CS_Low();                                      // Chip Select aktivieren
  uint8_t msb = spi_transfer(0x00);              // Erste 2*Dummybit + 1*NULLbit + 5*Datenbits (rechtsb�ndig)
  uint8_t lsb = spi_transfer(0x00);              // Letzte 7 Datenbits (linksb�ndig)
  CS_High();                                     // Chip Select deaktivieren

  result = ((uint16_t)msb << 8) | lsb;           // msb und lsb zu 16Bit zusammenbauen
  result &= 0x1FFF;                              // 2*Dummybit + 1* NUllbit ausmaskieren
  result >>= 1;                                  // 12-Bit rechtsb�ndig

  return result;
}
