/*
	Programm:		        
  Beschreibung:       

	Autor:              
	Datum:			        24.04.2017
  letzte �nderung:  		
*/

#include "controller.h"

#define CS    _PORTB_,2
#define DOUT  _PORTB_,4
#define CLK   _PORTB_,5

uint16_t adc1268_in(void);

float messbereich = 100.0 -(-25.0);
float aufloesung = 4095.0;    // 12 Bit
//float aufloesung = 1023.0;  // 10 Bit

uint16_t temp_buf[] = {0,0,0,0,0,0,0,0,0,0};    // Ringpuffer mit 10 x 0
#define NR_POINTS 10
    
void setup (void)   // Initialisierungen
{
  bit_init(CS, OUT);
  bit_init(DOUT, IN);
  bit_init(CLK,OUT);
  
	adc_init();
  rs232_init();
  lcd_init();
  lcd_clear();
  lcd_bigchar_init();
}

int main (void)
{
  volatile uint16_t raw;
  uint16_t temp;
  uint8_t n;
  
  uint8_t i=0;
  
  float temperatur;
  uint8_t buffer[8];
    
	setup();
	
	while(1)          // loop()
	{
		lcd_setcursor(2,1);
		temp =0;
    
    temp_buf[i++] = adc1268_in();
    //temp_buf[i++] = adc_in10(0);
    
    if (i>=NR_POINTS) i = 0;     // Ringindex reset
    
    for (n=0; n<NR_POINTS; n++)  // Mittelwert aus NR_POINTS Messungen
    {
        temp += temp_buf[n];
    }
    
    raw = temp/n;
 
    temperatur = messbereich/aufloesung * (float)raw - 25.0;
    if(temperatur < 0.1 && temperatur>-0.1) temperatur = 0;
    
    dtostrf(temperatur,6,3,buffer);
    rs232_print(buffer);rs232_put('\r');
    uint8_t z=2,s=2;    //Startposition z: Zeile, s: Spalte
    
    if(buffer[0] == '-')  
      lcd_bigchar(buffer[0],z,s++);	 // - Vorzeichen
    else
    { 
      lcd_bigchar(' ',z,s++);
      lcd_bigchar(buffer[0],z,s);  // 1. Ganzzahl
      s+=2;
    }
    
    if ((buffer[1] == '.') || (buffer[1] == ','))
       lcd_bigchar(buffer[1],z,s++);  // Komma     Bsp: -6, 
    else
    {       
      lcd_bigchar(buffer[1],z,s);  // 2. Ganzzahl    Bsp: -16
      s+=2;
    }
    
    if ((buffer[2] == '.') || (buffer[2] == ','))
      lcd_bigchar(buffer[2],z,s++);  // Komma          Bsp: -16,
    else
    {
      lcd_bigchar(buffer[2],z,s);  // 3. Ganzzahl     Bsp: -163,
      s+=2;
    }
    
    if ((buffer[3] == '.') || (buffer[3] == ','))
      lcd_bigchar(buffer[3],z,s++);  // Komma
    else
    {
      lcd_bigchar(buffer[3],z,s);  // 3. Ganzzahl
      s+=2;
    }    

    lcd_bigchar(buffer[4],z,s);    // 4. Ganzzahl
    s+=2;
    
    if (temperatur<0) lcd_bigchar(buffer[5],z,s);
    
    lcd_print(" �C");
    lcd_setcursor(2,12);
    lcd_int(raw);
    delay_ms(500);
	}
}

void setDCLK(uint8_t level)
{
    delay_100us(1);
    bit_write(CLK,level);
}

uint16_t adc1268_in(void)
{
  volatile uint16_t result;
  volatile uint8_t temp;
  
  bit_write(CS,0);
  
  for (uint8_t i = 0; i<3; i++)
  {
    setDCLK(0);
    setDCLK(1);
  }

  setDCLK(0);
  
  for (uint8_t bitcount=12; bitcount>0;bitcount--)
  {
    setDCLK(1);
    
    temp = bit_read(DOUT);
    result <<= 1;
    result |= temp;

    setDCLK(0);
  }
  bit_write(CS,1);
  delay_100us(2);   // Conversion time
  
  return result;
}
