#include <controller.h>

#define CS    PORTy,2
#define DOUT  PORTy,4
#define DCLK  PORTy,5

uint16_t adc1268_in(void);

void setup()
{
  bit_init(CS, OUT);
  bit_init(DOUT, IN);
  bit_init(DCLK,OUT);
  
	adc_init();
  lcd_init();
  lcd_clear();
}

void loop() 
{
  uint32_t temp;
  int32_t  temperatur;

  temp = adc1268_in();
  temperatur = temp * 1000;               // max. 4095x1000 = 4095000
                                            // Ist nötig, damit beim Kürzen
                                            // kein Genauigkeitsverlust auftritt.
                                            // Rechnung für eine Nachkommastelle
  temperatur = temperatur/3276 - 250;     // 3276 = Auflösung/Messbereich * 100
                                            // Offset: 25(°C) * 100 abziehen.
                                            // temperatur ist mit Faktor 10 für 
                                            // eine Nachkommastelle gespeichert.
    
  lcd_setcursor(1,4);
    
  if (temperatur<0) 
  { 
    temperatur = -temperatur;
    lcd_char('-');
  }
  else lcd_char(' ');
    
  lcd_int(temperatur/10);lcd_char(',');lcd_char(temperatur%10+0x30);    
  lcd_print(" °C");
  lcd_setcursor(2,12);
  lcd_int(temp);
  delay_ms(500);
}

void setDCLK(uint8_t state)
{
    bit_write(DCLK,state);
    delay_100us(1);
}

uint16_t adc1268_in(void)
{
  volatile uint16_t result;
  volatile uint8_t temp;
  
  bit_write(CS,0);
  
  for (uint8_t i = 0; i<3; i++)
  {
    setDCLK(0);
    setDCLK(1);
  }

  setDCLK(0);
  
  for (uint8_t bitcount=12; bitcount>0;bitcount--)
  {
    setDCLK(1);
        
    temp = bit_read(DOUT);
    result <<= 1;
    result |= temp;

    setDCLK(0);
  }
  bit_write(CS,1);
  delay_100us(2);   // Conversion time
  
  return result;
}


