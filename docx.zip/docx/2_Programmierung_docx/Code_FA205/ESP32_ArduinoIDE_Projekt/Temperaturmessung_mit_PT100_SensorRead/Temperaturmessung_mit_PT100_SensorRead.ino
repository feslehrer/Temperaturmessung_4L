#include <controller.h>

#define CS    PORTy,2
#define DOUT  PORTy,4
#define DCLK  PORTy,5

uint16_t adc1268_in(void);

void setup()
{
  bit_init(CS, OUT);
  bit_init(DOUT, IN);
  bit_init(DCLK,OUT);
  
	adc_init();
  lcd_init();
  lcd_clear();
  lcd_print(" Rohwert:");
}

void loop() 
{
  uint16_t raw = adc1268_in();
  lcd_setcursor(2,6);
  
  lcd_int(raw);
  delay_ms(100);
}

void setDCLK(uint8_t state)
{
    bit_write(DCLK,state);
    delay_100us(1);
}

uint16_t adc1268_in(void)
{
  volatile uint16_t result;
  volatile uint8_t temp;
  
  bit_write(CS,0);
  
  for (uint8_t i = 0; i<3; i++)
  {
    setDCLK(0);
    setDCLK(1);
  }

  setDCLK(0);
  
  for (uint8_t bitcount=12; bitcount>0;bitcount--)
  {
    setDCLK(1);
        
    temp = bit_read(DOUT);
    result <<= 1;
    result |= temp;

    setDCLK(0);
  }
  bit_write(CS,1);
  delay_100us(2);   // Conversion time
  
  return result;
}


